package chests;

public interface Chests {
	public abstract int changePoints(int points);
}
