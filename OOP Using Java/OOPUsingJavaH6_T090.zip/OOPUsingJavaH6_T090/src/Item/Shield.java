package Item;

public class Shield extends Item {

	public Shield(String name, int points) {
		super(name, points, name);
		// TODO Auto-generated constructor stub
	}

}
