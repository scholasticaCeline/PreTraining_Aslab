package Item;

public class Normal extends Item {

	public Normal(String name, int points) {
		super(name, points, name);
		// TODO Auto-generated constructor stub
	}

}
