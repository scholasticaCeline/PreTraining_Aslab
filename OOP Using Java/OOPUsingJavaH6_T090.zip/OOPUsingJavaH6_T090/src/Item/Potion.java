package Item;

public class Potion extends Item {

	public Potion(String name, int points) {
		super(name, points, name);
		// TODO Auto-generated constructor stub
	}

}
